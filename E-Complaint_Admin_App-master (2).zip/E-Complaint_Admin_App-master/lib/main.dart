import 'package:complaint_portal_admin_app/Screens/LoginScreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization, // Initialize FlutterFire:
      builder: (context, snapshot) {
        if (snapshot.hasError) // Check for errors
          return MaterialApp(
            home: Scaffold(
              body: Container(
                child: Center(
                  child: Text('Something Went Wrong'),
                ),
              ),
            ),
          );
        if (snapshot.connectionState ==
            ConnectionState.done) // Once complete, show your application
          return MaterialApp(
            theme: ThemeData.dark()
                .copyWith(outlinedButtonTheme: OutlinedButtonThemeData()),
            home: LogInScreen(),
          );
        return MaterialApp(
          // Otherwise, show something waiting for initialization to complete
          home: Scaffold(
            body: Container(
              child: Center(
                child: CircularProgressIndicator(
                  strokeWidth: 5,
                  semanticsLabel: 'Loading..',
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
