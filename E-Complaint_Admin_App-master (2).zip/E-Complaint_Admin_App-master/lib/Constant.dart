import 'package:flutter/painting.dart';

const kcolors = [
  Color(0xff3FA761),
  Color(0xff3FA5A1),
];
const kTextColor = Color(0xff3FA5A1);

const kBoxDecoration = BoxDecoration(
  gradient: LinearGradient(
    colors: kcolors,
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  ),
);

