import 'package:cloud_firestore/cloud_firestore.dart';

String getDateTime(Timestamp s) {
  String ans = '';
  ans += s.toDate().hour.toString();
  ans += ':';
  ans += s.toDate().minute.toString();
  ans += ' ';
  ans += s.toDate().day.toString();
  ans += '/';
  ans += s.toDate().month.toString();
  ans += '/';
  ans += s.toDate().year.toString();
  return ans;
}
