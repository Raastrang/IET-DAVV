import 'package:flutter/material.dart';
import 'dart:ui' as ui;

class RPSCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint_0 = new Paint()
      ..color = Color.fromARGB(137, 255, 255, 255)
      ..style = PaintingStyle.fill
      ..strokeWidth = 1.0;
    paint_0.shader = ui.Gradient.linear(
        Offset(size.width * 0.00, size.height * 0.34),
        Offset(size.width * 0.97, size.height * 0.34),
        [Color(0x14000000), Color(0xffffffff)],
        [0.00, 1.00]);

    Path path_0 = Path();
    path_0.moveTo(size.width * 0.0008621, size.height * 0.3100000);
    path_0.quadraticBezierTo(size.width * 0.0746897, size.height * 0.1591000,
        size.width * 0.3135431, size.height * 0.7235000);
    path_0.quadraticBezierTo(size.width * 0.4828276, size.height * 0.8568000,
        size.width * 0.6172672, size.height * 0.1363000);
    path_0.quadraticBezierTo(size.width * 0.7755603, size.height * -0.2695000,
        size.width * 0.9094828, size.height * 0.5700000);
    path_0.lineTo(size.width * 0.9709397, size.height * 0.7751000);
    path_0.lineTo(size.width * 0.0008621, size.height * 0.9500000);
    path_0.quadraticBezierTo(size.width * 0.0008621, size.height * 0.7900000,
        size.width * 0.0008621, size.height * 0.3100000);
    path_0.close();

    canvas.drawPath(path_0, paint_0);

    Paint paint_2 = new Paint()
      ..color = Color.fromARGB(255, 255, 255, 255)
      ..style = PaintingStyle.fill
      ..strokeWidth = 1.0;

    Path path_2 = Path();
    path_2.moveTo(size.width * 0.0008621, size.height * 0.8500000);
    path_2.quadraticBezierTo(size.width * 0.0511034, size.height * 0.5867000,
        size.width * 0.1431034, size.height * 0.6500000);
    path_2.quadraticBezierTo(size.width * 0.2532694, size.height * 0.7799000,
        size.width * 0.2899914, size.height * 0.8232000);
    path_2.cubicTo(
        size.width * 0.3700259,
        size.height * 0.8615000,
        size.width * 0.4869375,
        size.height * 0.5583000,
        size.width * 0.5525862,
        size.height * 0.4700000);
    path_2.cubicTo(
        size.width * 0.6232241,
        size.height * 0.2825000,
        size.width * 0.6791164,
        size.height * 0.7100000,
        size.width * 0.7212931,
        size.height * 0.7900000);
    path_2.cubicTo(
        size.width * 0.7751983,
        size.height * 0.8542000,
        size.width * 0.8432198,
        size.height * 0.5005000,
        size.width * 0.8838621,
        size.height * 0.4040000);
    path_2.quadraticBezierTo(size.width * 0.9865862, size.height * 0.3204000,
        size.width * 1.0344828, size.height);
    path_2.lineTo(0, size.height);
    path_2.quadraticBezierTo(size.width * 0.0002155, size.height * 0.9400000,
        size.width * 0.0008621, size.height * 0.8500000);
    path_2.close();

    canvas.drawPath(path_2, paint_2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
