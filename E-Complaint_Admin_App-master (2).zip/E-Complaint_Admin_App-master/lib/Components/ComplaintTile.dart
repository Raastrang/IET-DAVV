import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:complaint_portal_admin_app/Function/Date.dart';
import 'package:complaint_portal_admin_app/Screens/ComplaintDashBoardScreen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

int steper = 0;

class ComplaintTile extends StatelessWidget {
  final String id;
  final Map<String, dynamic> complaintData;
  final Map<String, dynamic> userData;
  final Function fun;
  final int currentStep;
  const ComplaintTile({
    Key key,
    this.complaintData,
    this.userData,
    this.currentStep,
    this.id,
    @required this.fun,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _scrollCTRL = ScrollController();
    steper = currentStep;
    return Scrollbar(
      isAlwaysShown: true,
      controller: _scrollCTRL,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: ListView(
          controller: _scrollCTRL,
          children: [
            Container(
              decoration: BoxDecoration(
                  color: Color(0xff04bca3),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(width: 2, color: Color(0xff212121))),
              padding: EdgeInsets.all(30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(25),
                      color: Colors.white,
                    ),
                    child: complaintCard(
                      text: complaintData['Subject'],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: double.infinity,
                    child: complaintCard(
                      text: complaintData['Complaint'],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  if (complaintData['Attachment'] != null)
                    ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.resolveWith(
                            (states) => Color(0xff212121)),
                      ),
                      onPressed: () async {
                        showDialog(
                            context: context,
                            builder: (context) => GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: FadeInImage(
                                      placeholder:
                                          AssetImage('assets/loader4.gif'),
                                      image: NetworkImage(
                                          complaintData['Attachment'])),
                                ));
                      },
                      child: Text('View Attachment'),
                    ),
                ],
              ),
            ),
            Tooltip(
              message: 'View User Image',
              child: GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: FadeInImage(
                          placeholder: AssetImage('assets/loader4.gif'),
                          image: getImageFromNetwork(userData['Profile']),
                        ),
                      ),
                    );
                  },
                  child: buildTile(Icons.person, userData['Name'])),
            ),
            buildTile(FontAwesomeIcons.envelopeSquare, complaintData['Email']),
            buildTile(
                findcatageryIcon(userData['Category']), userData['Category']),
            buildTile(Icons.phone, userData['Phone']),
            buildTile(FontAwesomeIcons.solidIdCard, userData['Enrollment']),
            buildTile(Icons.calendar_today_rounded,
                getDateTime(complaintData['Date'])),
            buildTile(FontAwesomeIcons.university, userData['Department']),
            MyStepper(
              id: id,
              status: complaintData['Status'],
              fun: fun,
              step: currentStep,
              complaintData: complaintData,
            ),
          ],
        ),
      ),
    );
  }

  Card complaintCard({String text, Color color = const Color(0xff212121)}) {
    return Card(
      borderOnForeground: true,
      shadowColor: Colors.white,
      color: color,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }

  ToggleButtons buildToggleButtons(List<bool> _isSelected) {
    return ToggleButtons(
      hoverColor: Colors.greenAccent,
      color: Colors.black,
      fillColor: Colors.green,
      disabledColor: Colors.red,
      borderRadius: BorderRadius.circular(20),
      onPressed: (id) {},
      selectedColor: Colors.white,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Seen'),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Under Review'),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Completed'),
        ),
      ],
      isSelected: [false, true, false],
    );
  }

  Padding buildTile(
    IconData icon,
    String data,
  ) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          tileColor: Color(0xff212121),
          leading: Icon(icon),
          title: Text(data),
        ),
      ),
    );
  }
}

class MyStepper extends StatefulWidget {
  final Map<String, dynamic> complaintData;
  final Function fun;
  final String id;
  final String status;
  final int step;
  const MyStepper({
    Key key,
    this.id,
    this.status,
    this.fun,
    this.step,
    this.complaintData,
  }) : super(key: key);

  @override
  _MyStepperState createState() => _MyStepperState();
}

class _MyStepperState extends State<MyStepper> {
  @override
  void initState() {
    steper = widget.step;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      decoration: BoxDecoration(
        color: Color(0xff212121),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 15),
            decoration: BoxDecoration(
              color: Color(0xff30555c),
              borderRadius: BorderRadius.circular(10),
              // border: Border.all(color: Colors.cyan),
            ),
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: Text(
                'Current Status',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
              ),
            ),
          ),
          Stepper(
            currentStep: steper,
            onStepCancel: () {
              if (steper <= 0) return;
              setState(() {
                steper--;
                changeStatusValueOnDB(
                  id: widget.id,
                  i: steper,
                  context: context,
                  fun: widget.fun,
                  complaintData: widget.complaintData,
                );
              });
            },
            onStepTapped: (id) {
              setState(
                () {
                  steper = id;
                  changeStatusValueOnDB(
                    id: widget.id,
                    i: steper,
                    context: context,
                    fun: widget.fun,
                    complaintData: widget.complaintData,
                  );
                },
              );
            },
            onStepContinue: () {
              if (steper >= 3) return;
              setState(() {
                steper++;
                changeStatusValueOnDB(
                  id: widget.id,
                  i: steper,
                  context: context,
                  fun: widget.fun,
                  complaintData: widget.complaintData,
                );
              });
            },
            steps: [
              Step(
                title: Icon(FontAwesomeIcons.eye),
                content:
                    buildTextContainer(text: 'Seen', color: Colors.cyanAccent),
              ),
              Step(
                title: Icon(FontAwesomeIcons.spinner),
                content: buildTextContainer(
                    text: 'In Progress', color: Colors.orangeAccent),
              ),
              Step(
                title: Icon(FontAwesomeIcons.clipboardCheck),
                content: buildTextContainer(
                    text: 'Completed', color: Colors.greenAccent),
              ),
              Step(
                title: Icon(FontAwesomeIcons.trash),
                content: buildTextContainer(
                    text: 'Delete', color: Colors.redAccent.shade100),
              )
            ],
          ),
        ],
      ),
    );
  }

  Container buildTextContainer(
      {String text, Color color = const Color(0xff30555C)}) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Text(
          text,
          style: TextStyle(
            color: Color(0xff212121),
            fontWeight: FontWeight.w400,
            fontStyle: FontStyle.italic,
            fontSize: 17,
          ),
        ),
      ),
    );
  }
}

Future<void> changeStatusValueOnDB({
  int i,
  String id,
  BuildContext context,
  Function fun,
  final Map<String, dynamic> complaintData,
}) async {
  FirebaseFirestore c = FirebaseFirestore.instance;
  switch (i) {
    case 0:
      {
        showDialogForDataProgcess(context);
        c.collection('Complaints').doc(id).update({'Status': 'Seen'});
        fun('Seen');
        Navigator.pop(context);
        break;
      }
    case 1:
      {
        showDialogForDataProgcess(context);
        c.collection('Complaints').doc(id).update({'Status': 'In Progress'});
        fun('In Progress');
        Navigator.pop(context);
        break;
      }
    case 2:
      {
        showDialogForDataProgcess(context);
        c.collection('Complaints').doc(id).update({'Status': 'Completed'});
        fun('Completed');
        Navigator.pop(context);
        break;
      }
    case 3:
      {
        showDialogForDataProgcess(context);
        await c.collection('Complaint History').doc(id).set(
          {
            'Complaint': complaintData['Complaint'],
            'Subject': complaintData['Subject'],
            'Status': 'Completed',
            'Date': DateTime.now(),
            'Email': complaintData['Email'],
          },
        );
        Navigator.pop(context);
        c.collection('Complaints').doc(id).delete();
        // Navigator.pop(context);
        fun('Completed');
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ComplaintDashBoardScreen(),
          ),
        );
        break;
      }
  }
}

void showDialogForDataProgcess(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => Center(child: CircularProgressIndicator()),
  );
}

ImageProvider<Object> getImageFromNetwork(String url) {
  try {
    return NetworkImage(url);
  } catch (e) {
    print(e);
    return AssetImage('assets/pic.jpg');
  }
}
